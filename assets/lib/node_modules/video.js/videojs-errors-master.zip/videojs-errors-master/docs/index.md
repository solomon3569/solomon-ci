# Documentation for videojs-errors
